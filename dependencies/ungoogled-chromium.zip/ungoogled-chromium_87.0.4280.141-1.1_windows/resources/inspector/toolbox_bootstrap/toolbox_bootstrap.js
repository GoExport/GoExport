runOnWindowLoad((function(){if(!window.opener)return;window.opener.Emulation.AdvancedApp._instance().toolboxLoaded(document)}));
